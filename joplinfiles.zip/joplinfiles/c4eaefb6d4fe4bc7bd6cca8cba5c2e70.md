d66554b963e94908e03475fb7d05eb70.png

id: c4eaefb6d4fe4bc7bd6cca8cba5c2e70
mime: image/png
filename: 
created_time: 2023-05-26T09:49:19.784Z
updated_time: 2023-05-26T09:49:19.784Z
user_created_time: 2023-05-26T09:49:19.784Z
user_updated_time: 2023-05-26T09:49:19.784Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 40771
is_shared: 0
share_id: 
master_key_id: 
type_: 4