08417b2c77585e0b727b398a0a5a6a8d.png

id: 623f3cae151147dcaadbda20ff99de5d
mime: image/png
filename: 
created_time: 2023-05-26T08:27:57.073Z
updated_time: 2023-05-26T08:27:57.073Z
user_created_time: 2023-05-26T08:27:57.073Z
user_updated_time: 2023-05-26T08:27:57.073Z
file_extension: png
encryption_cipher_text: 
encryption_applied: 0
encryption_blob_encrypted: 0
size: 37400
is_shared: 0
share_id: 
master_key_id: 
type_: 4